import React from "react"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { DashboardHeader } from "@/components/dashboard/header"

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const userRole = user.user_metadata?.role || "student"
  const fullName = user.user_metadata?.full_name || user.email

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar userRole={userRole} />
      <div className="flex flex-1 flex-col">
        <DashboardHeader user={{ email: user.email!, fullName, role: userRole }} />
        <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  )
}
