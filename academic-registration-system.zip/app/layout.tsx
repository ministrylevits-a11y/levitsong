import React from "react"
import type { Metadata, Viewport } from "next"
import { Inter, Space_Grotesk } from "next/font/google"
import "./globals.css"

const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-inter",
})

const spaceGrotesk = Space_Grotesk({ 
  subsets: ["latin"],
  variable: "--font-space",
})

export const metadata: Metadata = {
  title: "EduSystem - Sistema Academico Integral",
  description: "Plataforma completa para gestion educativa: clases, asistencias, calificaciones, reuniones y mas.",
  generator: "v0.app",
  keywords: ["educacion", "sistema academico", "gestion escolar", "asistencias", "calificaciones"],
}

export const viewport: Viewport = {
  themeColor: "#3b82f6",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body className={`${inter.variable} ${spaceGrotesk.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  )
}
